﻿
// MFCApplication1Dlg.cpp: 구현 파일
//

#include "pch.h"
#include "framework.h"
#include "MFCApplication1.h"
#include "MFCApplication1Dlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// 응용 프로그램 정보에 사용되는 CAboutDlg 대화 상자입니다.

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

// 구현입니다.
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CMFCApplication1Dlg 대화 상자



CMFCApplication1Dlg::CMFCApplication1Dlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_MFCAPPLICATION1_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMFCApplication1Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_STATIC_ORG, m_PIC_ORG);
}

BEGIN_MESSAGE_MAP(CMFCApplication1Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_LOAD, &CMFCApplication1Dlg::OnBnClickedButtonLoad)
	ON_BN_CLICKED(IDC_BUTTON_CANCEL, &CMFCApplication1Dlg::OnBnClickedButtonCancel)
	ON_BN_CLICKED(IDC_BUTTON_SAVE, &CMFCApplication1Dlg::OnBnClickedButtonSave)
	ON_BN_CLICKED(IDC_BUTTON_CROP, &CMFCApplication1Dlg::OnBnClickedButtonCrop)
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
END_MESSAGE_MAP()


// CMFCApplication1Dlg 메시지 처리기

BOOL CMFCApplication1Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 시스템 메뉴에 "정보..." 메뉴 항목을 추가합니다.

	// IDM_ABOUTBOX는 시스템 명령 범위에 있어야 합니다.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 이 대화 상자의 아이콘을 설정합니다.  응용 프로그램의 주 창이 대화 상자가 아닐 경우에는
	//  프레임워크가 이 작업을 자동으로 수행합니다.
	SetIcon(m_hIcon, TRUE);			// 큰 아이콘을 설정합니다.
	SetIcon(m_hIcon, FALSE);		// 작은 아이콘을 설정합니다.

	// TODO: 여기에 추가 초기화 작업을 추가합니다.
	return TRUE;  // 포커스를 컨트롤에 설정하지 않으면 TRUE를 반환합니다.
}

void CMFCApplication1Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 대화 상자에 최소화 단추를 추가할 경우 아이콘을 그리려면
//  아래 코드가 필요합니다.  문서/뷰 모델을 사용하는 MFC 애플리케이션의 경우에는
//  프레임워크에서 이 작업을 자동으로 수행합니다.

void CMFCApplication1Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 그리기를 위한 디바이스 컨텍스트입니다.

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 클라이언트 사각형에서 아이콘을 가운데에 맞춥니다.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 아이콘을 그립니다.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// 사용자가 최소화된 창을 끄는 동안에 커서가 표시되도록 시스템에서
//  이 함수를 호출합니다.
HCURSOR CMFCApplication1Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CMFCApplication1Dlg::OnBnClickedButtonLoad()
{
	CString strPathName = _T("");
	CString strFileName = _T("");
	int nFindIndex = -1;

	CRect rect;//픽쳐 컨트롤의 크기를 저장할 CRect 객체
	m_PIC_ORG.GetWindowRect(rect);//GetWindowRect를 사용해서 픽쳐 컨트롤의 크기를 받는다.
	CDC* dc; //픽쳐 컨트롤의 DC를 가져올  CDC 포인터
	dc = m_PIC_ORG.GetDC(); //픽쳐 컨트롤의 DC를 얻는다.

	// 파일 LOAD 해서 불러오기.
	static TCHAR BASED_CODE szFilter[] = _T("이미지 파일(*.BMP, *.GIF, *.JPG) | *.BMP;*.GIF;*.JPG;*.bmp;*.jpg;*.gif |모든파일(*.*)|*.*||");

	CFileDialog dlg(TRUE, _T("*.jpg"), _T("image"), OFN_HIDEREADONLY, szFilter);

	if (IDOK == dlg.DoModal())
	{
		// 이미 ORG 이미지가 있으면 파괴하고 다시
		if (!m_ORG_IMG.IsNull())
		{
			m_ORG_IMG.Destroy();
		}

		strPathName = dlg.GetPathName();
		nFindIndex = strPathName.ReverseFind(_T('\\'));
		strFileName = strPathName.Mid(nFindIndex+1);

		m_ORG_IMG.Load(strFileName);//이미지 로드

		m_ORG_IMG.StretchBlt(dc->m_hDC, 0, 0, rect.Width(), rect.Height(), SRCCOPY); //이미지를 픽쳐 컨트롤 크기로 조정
	}

	ReleaseDC(dc);//DC 해제
}


void CMFCApplication1Dlg::OnBnClickedButtonCancel()
{
	SendMessage(WM_CLOSE, 0, 0);
}

// 미완성, 구현필요
void CMFCApplication1Dlg::OnBnClickedButtonSave()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	FILE* m_pFile;

	TCHAR BASED_CODE szFilter[] = _T("Image(*.BMP,*.PNG,*.JPG) | *.BMP;*.bmp;*.PNG;*.png;*.JPG;*.jpg | 모든파일(*.*) |*.*|");

	// TRUE 일 때 오픈, FALSE 일 때 저장
	CFileDialog dlg(FALSE, szFilter, 0, OFN_HIDEREADONLY, szFilter);

	// OK 버튼을 눌렀을 때

	if (dlg.DoModal() == IDOK)
	{
		// 경로 이름 받아오기
		m_strPath = dlg.GetPathName();
	}
}

// 키보드 ESC || ENTER (Return) 으로 인한 다이얼로그 종료 방지
BOOL CMFCApplication1Dlg::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_KEYDOWN)
	{
		// 키보드가 눌렸을 때
		switch (pMsg->wParam)
		{
			// ESC 버튼
		case VK_ESCAPE:
			// ENTER (RETURN) 버튼
			return TRUE;
		case VK_RETURN:
			return TRUE;
		default:
			break;
		}
	}
	return CDialogEx::PreTranslateMessage(pMsg);
}

void CMFCApplication1Dlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	// 이전에 그린 사각형이 있으면 지우고 시작하려고 -> 원본 이미지까지 삭제됨. 다시 구성 필요
	//if (bIsBeforeDraw && !bIsDraw)
	//{
	//	Invalidate();
	//	UpdateWindow();
	//}
	
	// 시작점 갱신
	pStartPos = point;
	pEndPos = point;

	// 현재 그리는 중인지
	bIsDraw = TRUE;

	SetCapture();

	CDialogEx::OnLButtonDown(nFlags, point);
}


void CMFCApplication1Dlg::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	if (bIsDraw)
	{
		CClientDC dc(this);
		CPen pRoiPen(PS_SOLID, 5, RGB(0, 255, 0));
		dc.SelectObject(&pRoiPen);
		dc.SelectObject(GetStockObject(NULL_BRUSH));
		pEndPos = point;
		
		// 최종 Rectangle Draw
		dc.Rectangle(CRect(pStartPos, pEndPos));
		bIsDraw = FALSE;
		bIsBeforeDraw = TRUE;
		ReleaseCapture();
	}
	CDialogEx::OnLButtonUp(nFlags, point);
}


void CMFCApplication1Dlg::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: 여기에 메시지 처리기 코드를 추가 및/또는 기본값을 호출합니다.
	if (bIsDraw)
	{
		CClientDC dc(this);
		CPen pRoiPen, * pOldPen;

		// 크기 0.5짜리 초록색 펜
		pRoiPen.CreatePen(PS_SOLID, 0.5, RGB(0, 255, 0));
		// 내부 채우지 않게 NULL BRUSH
		dc.SelectObject(GetStockObject(NULL_BRUSH));
		dc.SetROP2(R2_XORPEN);
		pOldPen = (CPen*)dc.SelectObject(&pRoiPen);

		// 이전 그림 지우기
		dc.Rectangle(pStartPos.x, pStartPos.y, pEndPos.x, pEndPos.y);
		// 끝점 갱신
		pEndPos = point;
		// 새로 그리기
		dc.Rectangle(pStartPos.x, pStartPos.y, pEndPos.x, pEndPos.y);
		dc.SelectObject(pOldPen);
	}
	CDialogEx::OnMouseMove(nFlags, point);
}

// BITMAPFILEHEADER 및 BITMAPINFOHEADER 공부 필요... (구글링)
//BYTE* cropBMP(BITMAPFILEHEADER* hf, BITMAPINFOHEADER* hinfo, BYTE* InputImg, int x1, int y1, int x2, int y2)
//{
//	int crop_width = x2 - x1, crop_height = y2 - y1;
//	int crop_size = crop_width * crop_height * 3;
//	int dif_size = hf->bfSize - hinfo->biSizeImage;
//	int width = hinfo->biWidth;
//
//	hinfo->biWidth = crop_width;
//	hinfo->biHeight = crop_height;
//	hinfo->biSizeImage = crop_size;
//	hf->bfSize = crop_size + hf->bfOffBits;
//
//	BYTE* OutputImg = NULL;
//	OutputImg = (BYTE*)malloc(sizeof(BYTE) * crop_size);
//
//	for (int i = 0; i < crop_width; i++)
//	{
//		for (int j = 0; j < crop_height; j++)
//		{
//			// RGB 3 채널 반복
//			for (int k = 0; k < 3; k++)
//			{
//				OutputImg[(3 * crop_width * j) + (3 * i) + k] = InputImg[(3 * width * (y1 + j)) + (3 * (x1 + i)) + k];
//			}
//		}
//	}
//
//	return OutputImg;
//}

// CROP 구현중
void CMFCApplication1Dlg::OnBnClickedButtonCrop()
{
	// TODO: 여기에 컨트롤 알림 처리기 코드를 추가합니다.
	if (!m_ORG_IMG.IsNull())
	{
		// 시작점과 끝점 차이가 길이
		int nWidth = abs(pEndPos.y - pStartPos.y);
		int nHeight = abs(pStartPos.x - pEndPos.x);

		// 자르는 부분 구현 중...
		m_CROP_IMG.Create(nWidth, nHeight, m_CROP_IMG.GetBPP());
		CRect rect;//픽쳐 컨트롤의 크기를 저장할 CRect 객체
		m_PIC_CROP.GetWindowRect(rect);//GetWindowRect를 사용해서 픽쳐 컨트롤의 크기를 받는다.
		CDC* dc; //픽쳐 컨트롤의 DC를 가져올  CDC 포인터
		dc = m_PIC_CROP.GetDC();
		m_ORG_IMG.Draw(m_CROP_IMG.GetDC(), 0, 0, nWidth, nHeight, pStartPos.x, pStartPos.y, nWidth, nHeight);
		m_CROP_IMG.StretchBlt(dc->m_hDC, 0, 0, rect.Width(), rect.Height(), SRCCOPY); //이미지를 픽쳐 컨트롤 크기로 조정
	}
}
