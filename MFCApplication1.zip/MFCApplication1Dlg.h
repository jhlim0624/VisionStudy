﻿
// MFCApplication1Dlg.h: 헤더 파일
//

#pragma once


// CMFCApplication1Dlg 대화 상자
class CMFCApplication1Dlg : public CDialogEx
{
// 생성입니다.
public:
	CMFCApplication1Dlg(CWnd* pParent = nullptr);	// 표준 생성자입니다.

// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MFCAPPLICATION1_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 지원입니다.


// 구현입니다.
protected:
	HICON m_hIcon;

	// 생성된 메시지 맵 함수
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	// 파일 관련
	afx_msg void OnBnClickedButtonLoad();
	afx_msg void OnBnClickedButtonSave();
	afx_msg void OnBnClickedButtonCancel();

	// 마우스 이동 관련
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);

	// ROI 영역 이미지 자르기
	afx_msg void OnBnClickedButtonCrop();

	BOOL PreTranslateMessage(MSG* pMsg);

	// 원본 이미지
	CStatic m_PIC_ORG;
	CImage	m_ORG_IMG;

	// 자른 이미지
	CStatic m_PIC_CROP;
	CImage m_CROP_IMG;

	// 로그
	CEdit m_Edit_Dist;

	// 이미지 경로
	CString m_strPath;


	// 시작점 끝점
	CPoint pStartPos;
	CPoint pEndPos;

	// 지금 그리고 있는가?
	BOOL bIsDraw;
	// 이전에 그린게 있는가?
	BOOL bIsBeforeDraw;
};
