﻿// VISION_3Dlg.cpp: 구현 파일
//

#include "pch.h"
#include "framework.h"
#include "VISION_3.h"
#include "VISION_3Dlg.h"
#include "afxdialogex.h"
#include <gdiplus.h>

using namespace Gdiplus;

#pragma comment(lib, "gdiplus.lib")

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// 응용 프로그램 정보에 사용되는 CAboutDlg 대화 상자입니다.

class CAboutDlg : public CDialogEx
{
public:
	CAboutDlg();

	// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 지원입니다.

	// 구현입니다.
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialogEx(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialogEx)
END_MESSAGE_MAP()


// CVISION3Dlg 대화 상자



CVISION3Dlg::CVISION3Dlg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_VISION_3_DIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CVISION3Dlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, m_Edit_His);
	DDX_Control(pDX, IDC_STATIC_ORG, m_PIC_ORG);
	DDX_Control(pDX, IDC_BUTTON_RECT, m_BTN_Fill_Rect);
}

BEGIN_MESSAGE_MAP(CVISION3Dlg, CDialogEx)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_LOAD, &CVISION3Dlg::OnBnClickedButtonLoad)
	ON_BN_CLICKED(IDC_BUTTON_RECT, &CVISION3Dlg::OnBnClickedButtonRect)
	ON_BN_CLICKED(IDC_BUTTON_SAVE, &CVISION3Dlg::OnBnClickedButtonSave)
	ON_BN_CLICKED(IDC_BUTTON_DELETE, &CVISION3Dlg::OnBnClickedButtonDelete)
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()


// CVISION3Dlg 메시지 처리기

BOOL CVISION3Dlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// 시스템 메뉴에 "정보..." 메뉴 항목을 추가합니다.

	// IDM_ABOUTBOX는 시스템 명령 범위에 있어야 합니다.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 이 대화 상자의 아이콘을 설정합니다.  응용 프로그램의 주 창이 대화 상자가 아닐 경우에는
	//  프레임워크가 이 작업을 자동으로 수행합니다.
	SetIcon(m_hIcon, TRUE);         // 큰 아이콘을 설정합니다.
	SetIcon(m_hIcon, FALSE);      // 작은 아이콘을 설정합니다.

	// TODO: 여기에 추가 초기화 작업을 추가합니다.
	nLogLength = -1;
	m_nPointIndex = 0;

	CRect rect;//픽쳐 컨트롤의 크기를 저장할 CRect 객체
	m_PIC_ORG.GetWindowRect(rect);//GetWindowRect를 사용해서 픽쳐 컨트롤의 크기를 받는다.

	CClientDC dc(this); // 화면 DC

	// 메모리 DC 생성
	m_memDC.CreateCompatibleDC(&dc);

	// 비트맵 생성
	m_bitmap.CreateCompatibleBitmap(&dc, rect.Width(), rect.Height());
	m_memDC.SelectObject(&m_bitmap);

	// 처음에는 채우기 버튼 안보이게
	m_BTN_Fill_Rect.ShowWindow(SW_HIDE);

	// 처음 시작 플래그 초기화
	bIsFirst = TRUE;

	return TRUE;  // 포커스를 컨트롤에 설정하지 않으면 TRUE를 반환합니다.
}

void CVISION3Dlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialogEx::OnSysCommand(nID, lParam);
	}
}

// 대화 상자에 최소화 단추를 추가할 경우 아이콘을 그리려면
//  아래 코드가 필요합니다.  문서/뷰 모델을 사용하는 MFC 애플리케이션의 경우에는
//  프레임워크에서 이 작업을 자동으로 수행합니다.

void CVISION3Dlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 그리기를 위한 디바이스 컨텍스트입니다.

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 클라이언트 사각형에서 아이콘을 가운데에 맞춥니다.
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 아이콘을 그립니다.
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// 사용자가 최소화된 창을 끄는 동안에 커서가 표시되도록 시스템에서
//  이 함수를 호출합니다.
HCURSOR CVISION3Dlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void CVISION3Dlg::OnBnClickedButtonLoad()
{
	CString strPathName = _T("");
	CString strFileName = _T("");
	int nFindIndex = -1;

	CRect rect;//픽쳐 컨트롤의 크기를 저장할 CRect 객체
	m_PIC_ORG.GetWindowRect(rect);//GetWindowRect를 사용해서 픽쳐 컨트롤의 크기를 받는다.
	CDC* dc; //픽쳐 컨트롤의 DC를 가져올  CDC 포인터
	dc = m_PIC_ORG.GetDC(); //픽쳐 컨트롤의 DC를 얻는다.

	// 파일 LOAD 해서 불러오기.
	static TCHAR BASED_CODE szFilter[] = _T("이미지 파일(*.BMP, *.GIF, *.JPG) | *.BMP;*.GIF;*.JPG;*.bmp;*.jpg;*.gif |모든파일(*.*)|*.*||");

	CFileDialog dlg(TRUE, _T("*.jpg"), _T("image"), OFN_HIDEREADONLY, szFilter);

	if (IDOK == dlg.DoModal())
	{
		// 이미 ORG 이미지가 있으면 파괴하고 다시
		if (!m_ORG_IMG.IsNull())
		{
			m_ORG_IMG.Destroy();
		}

		// 이미지 경로
		strPathName = dlg.GetPathName();
		nFindIndex = strPathName.ReverseFind(_T('\\'));
		strFileName = strPathName.Mid(nFindIndex + 1);

		m_ORG_IMG.Load(strFileName);//이미지 로드

		strLog.Format(_T("이미지 LOAD 완료! : %s \r\n"), strFileName);

		WriteLog(strLog);

		m_ORG_IMG.StretchBlt(dc->m_hDC, 0, 0, rect.Width(), rect.Height(), SRCCOPY); //이미지를 픽쳐 컨트롤 크기로 조정
	}

	ReleaseDC(dc);//DC 해제
}
// 로그남기기
void CVISION3Dlg::WriteLog(CString strLog)
{
	nLogLength = m_Edit_His.GetWindowTextLengthW();

	m_Edit_His.SetSel(nLogLength, nLogLength);

	m_Edit_His.ReplaceSel(strLog);
}

// 키보드 ESC || ENTER (Return) 으로 인한 다이얼로그 종료 방지
BOOL CVISION3Dlg::PreTranslateMessage(MSG* pMsg)
{
	if (pMsg->message == WM_KEYDOWN)
	{
		// 키보드가 눌렸을 때
		switch (pMsg->wParam)
		{
			// ESC 버튼
		case VK_ESCAPE:
			// ENTER (RETURN) 버튼
			return TRUE;
		case VK_RETURN:
			return TRUE;
		default:
			break;
		}
	}
	return CDialogEx::PreTranslateMessage(pMsg);
}

void CVISION3Dlg::OnLButtonDown(UINT nFlags, CPoint point)
{
	CClientDC dc(this);

	HDC memdc = CreateCompatibleDC(dc);

	// HORI : - , VERTI : I 방향 선 긋기
	CPen pCrossPenHori, pCrossPenVerti;

	// Point 들끼리 연결하는 Line 을 긋는 Pen
	CPen pLinePen;

	if (m_ORG_IMG.IsNull())
	{
		return;
	}

	// 사각형을 이미 다 그렸으면 더 못 그리게 알람을 띄운다
	if (m_nPointIndex == 4)
	{
		MessageBox(_T("이미 그려진 오버레이가 존재합니다"), _T("OVERLAY INDEX ERROR"), MB_OK);
		return;
	}

	CRect rect;//픽쳐 컨트롤의 크기를 저장할 CRect 객체
	m_PIC_ORG.GetWindowRect(rect);//GetWindowRect를 사용해서 픽쳐 컨트롤의 크기를 받는다.

	if (bIsFirst)
	{
		// 원본 이미지가 있으면 복사
		if (!m_ORG_IMG.IsNull())
		{
			CDC* pImgDC = CDC::FromHandle(m_ORG_IMG.GetDC());

			// 스트레치해서 m_memDC에 복사
			m_memDC.SetStretchBltMode(HALFTONE);
			m_memDC.StretchBlt(
				0, 0, rect.Width(), rect.Height(),  // m_memDC 내부 좌표
				pImgDC,
				0, 0, m_ORG_IMG.GetWidth(), m_ORG_IMG.GetHeight(),
				SRCCOPY
			);

			m_ORG_IMG.ReleaseDC();
		}

		//픽처컨트롤 rect 에 맞춰서 복사를 해준다
		dc.BitBlt(rect.left, rect.top, rect.Width(), rect.Height(), &m_memDC, 0, 0, SRCCOPY);

		bIsFirst = FALSE;
	}

	// 현재 마우스의 클릭 좌표를 받아오고
	GetCursorPos(&point);

	// 현재 마우스 클릭 좌표와 RECT 좌표 기준점 동일화
	ScreenToClient(rect);
	ScreenToClient(&point);

	// 만약 원본 이미지 안에서 시작한게 아니면 건너뛰기
	if (!rect.PtInRect(point))
	{
		return;
	}

	// 찍은 포인트의 Index 마다 다른 동작 (인덱스 체크)
	if (m_nPointIndex == 0)
	{
		pPoint1 = point;
	}
	else if (m_nPointIndex == 1)
	{
		pPoint2 = point;

		// Point 1 과 Point 2 를 연결한다
		pLinePen.CreatePen(PS_SOLID, 0.5, RGB(0, 140, 255));
		m_memDC.SelectObject(&pLinePen);
		m_memDC.SelectObject(GetStockObject(NULL_BRUSH));

		// 연결 수행
		m_memDC.MoveTo(pPoint1.x, pPoint1.y);
		m_memDC.LineTo(pPoint2.x, pPoint2.y);

		//Pen 복원
		CPen* pOldPen = m_memDC.SelectObject(&pLinePen);

		// 다쓴 펜 삭제
		pLinePen.DeleteObject();
	}
	else if (m_nPointIndex == 2)
	{
		pPoint3 = point;

		// 일직선에 있을 때
		if (0 == CCW(pPoint1, pPoint2, pPoint3))
		{
			// 3번째 Point 의 X 랑 Y 가 Point 1 과 Point 2 의 X, Y 범위 사이에 있다 :
			// Point 3 이 Point 1 과 2 를 이은 선분 위에 있다.
			if (min(pPoint1.x, pPoint2.x) <= pPoint3.x && max(pPoint1.x, pPoint2.x) >= pPoint3.x &&
				min(pPoint1.y, pPoint2.y) <= pPoint3.y && max(pPoint1.y, pPoint2.y) >= pPoint3.y)
			{
				MessageBox(_T("선분이 교차하였습니다. 다시 그려주세요"), _T("OVERLAY INDEX ERROR"), MB_OK);
				return;
			}
		}

		// 크로스 중 가로선을 그릴 펜을 만든다
		pLinePen.CreatePen(PS_SOLID, 0.5, RGB(0, 140, 255));
		m_memDC.SelectObject(&pLinePen);
		m_memDC.SelectObject(GetStockObject(NULL_BRUSH));

		// 연결 수행
		m_memDC.MoveTo(pPoint2.x, pPoint2.y);
		m_memDC.LineTo(pPoint3.x, pPoint3.y);

		//Pen 복원
		CPen* pOldPen = m_memDC.SelectObject(&pLinePen);

		// 다쓴 펜 삭제
		pLinePen.DeleteObject();
	}
	else if (m_nPointIndex == 3)
	{
		pPoint4 = point;

		// 1-2 라인과 3-4 라인이 교차하였을 때
		if ((0 >= CCW(pPoint1, pPoint2, pPoint3) * CCW(pPoint1, pPoint2, pPoint4)) &&
			(0 >= CCW(pPoint3, pPoint4, pPoint1) * CCW(pPoint3, pPoint4, pPoint2)))
		{
			MessageBox(_T("선분이 교차하였습니다. 다시 그려주세요"), _T("OVERLAY INDEX ERROR"), MB_OK);
			return;
		}
		// 1-4 라인과 2-3 라인이 교차하였을 때
		else if ((0 >= CCW(pPoint1, pPoint4, pPoint2) * CCW(pPoint1, pPoint4, pPoint3)) &&
			(0 >= CCW(pPoint2, pPoint3, pPoint1) * CCW(pPoint2, pPoint3, pPoint4)))
		{
			MessageBox(_T("선분이 교차하였습니다. 다시 그려주세요"), _T("OVERLAY INDEX ERROR"), MB_OK);
			return;
		}

		// 크로스 중 가로선을 그릴 펜을 만든다
		pLinePen.CreatePen(PS_SOLID, 0.5, RGB(0, 140, 255));
		m_memDC.SelectObject(&pLinePen);
		m_memDC.SelectObject(GetStockObject(NULL_BRUSH));

		// 연결 수행
		m_memDC.MoveTo(pPoint3.x, pPoint3.y);
		m_memDC.LineTo(pPoint4.x, pPoint4.y);

		// 첫번째 점이랑도 연결해주어야 함
		m_memDC.MoveTo(pPoint1.x, pPoint1.y);
		m_memDC.LineTo(pPoint4.x, pPoint4.y);

		//Pen 복원
		CPen* pOldPen = m_memDC.SelectObject(&pLinePen);

		// 다쓴 펜 삭제
		pLinePen.DeleteObject();

		// 사각형 채우기 버튼 활성화
		m_BTN_Fill_Rect.ShowWindow(SW_SHOW);
	}

	// 크로스 중 가로선을 그릴 펜을 만든다
	pCrossPenHori.CreatePen(PS_SOLID, 1, RGB(0, 255, 0));
	m_memDC.SelectObject(&pCrossPenHori);
	m_memDC.SelectObject(GetStockObject(NULL_BRUSH));

	// 찍은 포인트를 중심으로 3만큼 전 ~ 3만큼 후까지 선을 그린다.
	m_memDC.MoveTo(point.x - 3, point.y);
	m_memDC.LineTo(point.x + 3, point.y);

	// 크로스 중 세로선을 그릴 펜을 만든다
	pCrossPenVerti.CreatePen(PS_SOLID, 1, RGB(0, 255, 0));
	m_memDC.SelectObject(&pCrossPenVerti);
	m_memDC.SelectObject(GetStockObject(NULL_BRUSH));

	// 찍은 포인트를 중심으로 3만큼 전 ~ 3만큼 후까지 선을 그린다.
	m_memDC.MoveTo(point.x, point.y - 3);
	m_memDC.LineTo(point.x, point.y + 3);

	// 메모리 DC를 원본 rect 에 복사 (픽처 컨트롤에)
	dc.BitBlt(
		rect.left, rect.top, rect.Width(), rect.Height(),
		&m_memDC,
		0, 0,
		SRCCOPY
	);

	// 로그 남기기
	strLog.Format(_T("Point %d : %d, %d \r\n"), m_nPointIndex + 1, point.x, point.y);

	WriteLog(strLog);

	// 포인트 인덱스 ++
	m_nPointIndex++;

	CDialogEx::OnLButtonDown(nFlags, point);
}


void CVISION3Dlg::OnBnClickedButtonDelete()
{
	CClientDC dc(this);
	CClientDC PictureControlDc(&m_PIC_ORG);

	// Point Index 초기화 (처음부터 Point 다시 찍을 수 있도록)
	m_nPointIndex = 0;

	// 채우기 버튼도 숨기기
	m_BTN_Fill_Rect.ShowWindow(SW_HIDE);

	CRect rect;//픽쳐 컨트롤의 크기를 저장할 CRect 객체
	m_PIC_ORG.GetClientRect(&rect);//Rect 의 Client 위치를 받아온다.

	// 이미지의 DC (CDC 인자로 받아오기)
	CDC* pImgDC = CDC::FromHandle(m_ORG_IMG.GetDC());

	// 스트레치해서 m_memDC에 복사
	m_memDC.StretchBlt(
		0, 0, rect.Width(), rect.Height(),  // m_memDC 내부 좌표
		pImgDC,
		0, 0, m_ORG_IMG.GetWidth(), m_ORG_IMG.GetHeight(),
		SRCCOPY
	);

	// 픽처 컨트롤에 복사해주기 위해 픽처 컨트롤의 DC를 받아와서 BitBlt
	PictureControlDc.BitBlt(0, 0, rect.Width(), rect.Height(), &m_memDC, 0, 0, SRCCOPY);

	m_ORG_IMG.ReleaseDC();

	// 로그 작성
	strLog.Format(_T("오버레이 삭제 완료! \r\n"));

	WriteLog(strLog);

	// 플래그 꺼주기 (다시 원본이미지 복사할 수 있게)
	bIsFirst = FALSE;
}

// 시계방향 / 반시계방향 체크 함수
int CVISION3Dlg::CCW(CPoint P1, CPoint P2, CPoint P3)
{
	long long ccwResult = (P2.x - P1.x) * (P3.y - P1.y) - (P2.y - P1.y) * (P3.x - P1.x);

	// 시계
	if (ccwResult < 0)
	{
		return -1;
	}
	//반시계
	else if (ccwResult > 0)
	{
		return 1;
	}
	//일직선
	else if (ccwResult == 0)
	{
		return 0;
	}
}


void CVISION3Dlg::OnBnClickedButtonRect()
{
	CClientDC dc(&m_PIC_ORG); // 픽쳐 컨트롤 DC

	CRect rect;
	m_PIC_ORG.GetClientRect(&rect);

	// 사각형이 완성되지 않았다면
	// 들어올 일은 없겠지만 혹시모르니 인터락 개념
	if (m_nPointIndex != 4)
	{
		MessageBox(_T("사각형이 완성되지 않았습니다."), _T("OVERLAY INDEX ERROR"), MB_OK);
		return;
	}

	// 사각형 포인트 4개
	POINT RectPoint[4] = { pPoint1, pPoint2, pPoint3, pPoint4 };

	// 메모리 DC에 그리기 위해서
	Graphics graphics(m_memDC.m_hDC);

	// 브러쉬 색상 설정
	SolidBrush brush(Color(128, 0, 0, 255)); // Alpha, R, G, B

	// GDI+ 형식으로 포인트 변환
	Point gdiPlusPoint[4];
	for (int i = 0; i < 4; i++)
		gdiPlusPoint[i] = Point(RectPoint[i].x, RectPoint[i].y);

	// 사각형 채우기
	graphics.FillPolygon(&brush, gdiPlusPoint, 4);

	// 메모리 DC에 복사
	dc.BitBlt(0, 0, rect.Width(), rect.Height(), &m_memDC, 0, 0, SRCCOPY);
	Invalidate(FALSE);

	// 로그 작성
	strLog.Format(_T("오버레이 채우기 완료 \r\n"));

	WriteLog(strLog);

}


void CVISION3Dlg::OnBnClickedButtonSave()
{
	CClientDC dc(this);
	CRect rect;
	m_PIC_ORG.GetClientRect(&rect); // 픽처 컨트롤 크기 기준

	TCHAR BASED_CODE szFilter[] = _T("Image(*.BMP,*.PNG,*.JPG) | *.BMP;*.bmp;*.PNG;*.png;*.JPG;*.jpg | 모든파일(*.*) |*.*|");

	// TRUE 일 때 오픈, FALSE 일 때 저장
	CFileDialog dlg(FALSE, szFilter, 0, OFN_HIDEREADONLY, szFilter);

	// OK 버튼을 눌렀을 때

	if (dlg.DoModal() == IDOK)
	{
		CImage SaveImage;

		// Save 용 이미지 생성 (Create)
		SaveImage.Create(rect.Width(), rect.Height(), 32); // 32비트

		// 메모리 DC를 SaveImage 에 복사한다.
		CDC* pImgDC = CDC::FromHandle(SaveImage.GetDC());
		pImgDC->BitBlt(0, 0, rect.Width(), rect.Height(), &m_memDC, 0, 0, SRCCOPY);
		SaveImage.ReleaseDC();

		CString strPath = _T("");

		// 경로 이름 받아오기
		strPath = dlg.GetPathName();

		SaveImage.Save(strPath);

		strLog.Format(_T("이미지 SAVE 완료!"));

		WriteLog(strLog);
	}
}
