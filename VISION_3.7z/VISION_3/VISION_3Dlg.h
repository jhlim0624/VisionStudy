﻿// VISION_3Dlg.h: 헤더 파일
//

#pragma once


// CVISION3Dlg 대화 상자
class CVISION3Dlg : public CDialogEx
{
	// 생성입니다.
public:
	CVISION3Dlg(CWnd* pParent = nullptr);   // 표준 생성자입니다.

	// 대화 상자 데이터입니다.
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_VISION_3_DIALOG };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);   // DDX/DDV 지원입니다.


	// 구현입니다.
protected:
	HICON m_hIcon;

	// 생성된 메시지 맵 함수
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	BOOL PreTranslateMessage(MSG* pMsg);

	afx_msg void OnBnClickedButtonLoad();
	afx_msg void OnBnClickedButtonRect();
	afx_msg void OnBnClickedButtonSave();
	afx_msg void OnBnClickedButtonDelete();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);

	// 원본 이미지
	CImage m_ORG_IMG;
	CStatic m_PIC_ORG;

	// 로그 작성 관련
	void WriteLog(CString strLog);
	CEdit m_Edit_His;
	CString strLog;
	int nLogLength;

	// 찍은 포인트가 몇번째인지 체크
	int m_nPointIndex;

	// 사각형 각 포인트 저장
	CPoint pPoint1;
	CPoint pPoint2;
	CPoint pPoint3;
	CPoint pPoint4;

	// CreateCompatibleDC 관련
	CDC m_memDC;
	CBitmap m_bitmap;

	// 처음 포인트를 찍는것인가 (원본이미지 복사 시점 관련)
	BOOL bIsFirst;

	// 시계방향 / 반시계방향 체크하는 함수
	int CCW(CPoint P1, CPoint P2, CPoint P3);

	// 채우기 버튼
	CButton m_BTN_Fill_Rect;
};
